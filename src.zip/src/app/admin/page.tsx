"use client";
import { supabase } from "@/lib/supabaseClient";
import { useEffect, useState } from "react";

type Row = {
  id: string;
  patient_code: string;
  full_name: string | null;
  city: string | null;
};

export default function AdminHome() {
  const [role, setRole] = useState<"patient" | "admin" | "doctor" | "unknown">(
    "unknown"
  );
  const [q, setQ] = useState("");
  const [rows, setRows] = useState<Row[]>([]);

  useEffect(() => {
    (async () => {
      const { data: auth } = await supabase.auth.getUser();
      if (!auth.user) {
        window.location.href = "/";
        return;
      }
      const { data: prof } = await supabase
        .from("profiles")
        .select("role")
        .eq("user_id", auth.user.id)
        .maybeSingle();
      const r = (prof?.role ?? "patient") as any;
      setRole(r);
      if (r === "patient") {
        window.location.href = "/dashboard";
        return;
      }
      await search("");
    })();
  }, []);

  async function search(term: string) {
    // Admin can read via policies; do a simple ilike on code or name
    const { data, error } = await supabase
      .from("patients")
      .select("id, patient_code, patient_demographics(full_name, city)")
      .ilike("patient_code", `%${term}%`);
    if (error) {
      alert(error.message);
      return;
    }

    const d2 = await supabase
      .from("patient_demographics")
      .select("patient_id, full_name, city")
      .ilike("full_name", `%${term}%`);

    // Merge results uniquely
    const map = new Map<string, Row>();
    (data || []).forEach((p: any) =>
      map.set(p.id, {
        id: p.id,
        patient_code: p.patient_code,
        full_name: p.patient_demographics?.full_name ?? null,
        city: p.patient_demographics?.city ?? null,
      })
    );
    (d2?.data || []).forEach((d: any) => {
      if (map.has(d.patient_id)) {
        const r = map.get(d.patient_id)!;
        r.full_name = r.full_name ?? d.full_name;
        r.city = r.city ?? d.city;
      } else {
        map.set(d.patient_id, {
          id: d.patient_id,
          patient_code: "",
          full_name: d.full_name,
          city: d.city,
        });
      }
    });
    setRows(Array.from(map.values()));
  }

  return (
    <main className="mx-auto max-w-5xl p-6">
      <h1 className="text-2xl font-semibold">Admin / Doctor — Patients</h1>
      <div className="mt-4 flex gap-2">
        <input
          className="w-full rounded-xl border px-3 py-2"
          placeholder="Search by Patient ID or name..."
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <button
          onClick={() => search(q)}
          className="rounded-xl bg-[#00b78b] px-4 py-2 font-semibold text-white"
        >
          Search
        </button>
      </div>

      <div className="mt-4 overflow-x-auto rounded-2xl border">
        <table className="min-w-full text-left text-sm">
          <thead>
            <tr className="border-b bg-slate-50">
              <th className="px-3 py-2">Patient ID</th>
              <th className="px-3 py-2">Name</th>
              <th className="px-3 py-2">City</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-b last:border-0">
                <td className="px-3 py-2 font-mono">{r.patient_code || "—"}</td>
                <td className="px-3 py-2">{r.full_name ?? "—"}</td>
                <td className="px-3 py-2">{r.city ?? "—"}</td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={3} className="px-3 py-8 text-slate-500">
                  No results.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </main>
  );
}
